package FB_Source;

import java.io.FileWriter;
import java.net.URL;
import java.util.Iterator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;



public class FB_Main {
	private static String api = "https://graph.facebook.com/";
	private static String version = "v2.5/";
	private static String token = "?access_token=1158688460828015|sBxWD12V-ACU2j2tCtGIzpoZaP8";
	private static int counter;
	

	private static final String COMMA_DELIMITER = ",";
	private static final String NEW_LINE_SEPARATOR = "\n";
	private static final String FILE_HEADER = "id,date,user,comment";
	private static FileWriter fileWriter = null;
	
	private static ObjectMapper mapper = new ObjectMapper();
	
	public static void main(String [] args){
		try {
			String id = "15704546335_10154315211016336";
			String comments = "&fields=comments.summary(true)";
			URL url = new URL (api + version + id + token + comments);
			System.out.println(url);
		
			counter = 1;
			createCSV("FBCommcents.csv");
			countItems(url);
			fileWriter.close();
		} catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	public static void createCSV(String fileName) {
		try {
			fileWriter = new FileWriter(fileName);
			fileWriter.append(FILE_HEADER.toString());
			fileWriter.append(NEW_LINE_SEPARATOR);
		} catch(Exception e){
			System.out.println(e.getMessage());
		}	
	}
	
	public static void writeCSV(int id, String date, String user, String message) {
		try {
			fileWriter.append(String.valueOf(id));
			fileWriter.append(COMMA_DELIMITER);
			fileWriter.append(date);
			fileWriter.append(COMMA_DELIMITER);
			fileWriter.append(user);
			fileWriter.append(COMMA_DELIMITER);
			fileWriter.append(message);
			fileWriter.append(NEW_LINE_SEPARATOR);
		} catch(Exception e){
			System.out.println(e.getMessage());
		}	
	}
	
	public static void countItems(URL query){
		try{
			JsonNode tree = mapper.readTree(query);
			JsonNode data = tree.findPath("data");
			if (data.isMissingNode()){
				System.out.println("no data");
			}
			if (!data.has(0)){
				System.out.println("Counted:" + counter);
				return;
			}
			
			Iterator<JsonNode> iterator = data.iterator();
			while (iterator.hasNext()){
				
				JsonNode comment = iterator.next(); //the comment
				String date = comment.findPath("created_time").asText();
				String user = comment.findPath("name").asText();
				String message = comment.findPath("message").asText();
				message = message.replace("\n", " ");
				writeCSV(counter,date,user,message);
				counter += 1;
				try {
					
				} catch(Exception e){
					System.out.println(e.getMessage());
					continue;
				}
			}
			JsonNode paging = tree.findPath("paging");
			paging = paging.path("next");
			if (paging.isMissingNode()){
				System.out.println("Counted:" + counter);
				return;
			}
			URL next = new URL(paging.asText());
			System.out.println("completed page with " + counter + " comments");
			countItems(next);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}